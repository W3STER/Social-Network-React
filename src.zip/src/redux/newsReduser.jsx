import { SHARE_NEWS } from "./types";
const initialState = {
    news: []
}

export const newsReducer = (state = initialState, action) => {
    switch(action.type){
        case SHARE_NEWS:
            return {
                ...state,
                news: [...state.news, action.payload]
            }
        default: return state
    }
}