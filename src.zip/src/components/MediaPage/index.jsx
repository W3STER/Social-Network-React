import React, { useState } from 'react'
import './mediaPage.css'

const streaming = [
    {
        name: 'House',
        url: 'http://streaming.tdiradio.com:8000/house.mp3'
    },
    {
        name: 'Chill Out',
        url: 'http://streaming.tdiradio.com:8000/chillout.mp3'
    }
]

export const MediaPage = props => {
    
    const [station, setStation] =  useState(streaming)
    const houseUrl = 'http://streaming.tdiradio.com:8000/house.mp3'
    const chillOut = 'http://streaming.tdiradio.com:8000/chillout.mp3'
    const audio = new Audio(props.url)
    const play = () => {
        audio.play()
    }
    const pause = () => {
        audio.pause()
    }
    return (
        <div>
            <div className="player-wrapper">
                <div className="player-description">House streaming</div>
                <div className="player-panel">
                    <button id="" onClick={play} className="play-btn" />
                    <button onClick={pause} className="pause-btn" />
                </div>
            </div>
        </div>
    )
}

