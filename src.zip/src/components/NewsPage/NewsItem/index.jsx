import React from 'react'
import './newsItem.css'
import { connect } from 'react-redux'
import { shareNews } from '../../../redux/actions'

export const NewsItemView = props => {

    const shareNewsToMyPost = () => {
        const newsPost = props.news
        props.shareNews(newsPost)
    }

    return (
        <div className="news-item-wrapper">
            <div className="caption source-name">{props.news.source.name}</div>
            <div className="img-box">
                <img className="news-img" src={props.news.urlToImage} />
            </div>
            {/* <div className="caption news-date">{props.news.publishedAt}</div> */}
            <h3 className="third-title"><a className="link" href={props.news.url}>{props.news.title}</a></h3>
            <div className="subtitle">{props.news.description}</div>

            <div className="btn-panel">
                <div className="btn-box">
                    <button className="share-btn" 
                        onClick={shareNewsToMyPost}
                    />
                </div>
            </div>

        </div>
    )
}

const mapDispatchToProps = {
    shareNews
}

export const NewsItem = connect(null, mapDispatchToProps)(NewsItemView)